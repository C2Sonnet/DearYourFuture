<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/autoload.php';
KMM\Core\Kernel::handle();
